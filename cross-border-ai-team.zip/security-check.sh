#!/bin/bash
echo "🔒 OpenClaw 安全自检"
echo "===================="

# 1. Gateway 绑定地址
echo -n "1. Gateway 绑定地址... "
BIND=$(netstat -ano 2>/dev/null | grep 18789 | head -1)
if echo "$BIND" | grep -q "127.0.0.1"; then
  echo "✅ 127.0.0.1"
elif echo "$BIND" | grep -q "0.0.0.0"; then
  echo "❌ 0.0.0.0 — 立即修改！"
else
  echo "⚠️ 未检测到 Gateway 运行"
fi

# 2. 版本检查
echo -n "2. OpenClaw 版本... "
VERSION=$(E:/develop/nodejs/node.exe E:/node_global/node_modules/openclaw/dist/index.js --version 2>/dev/null)
if [ -n "$VERSION" ]; then
  echo "✅ $VERSION"
else
  echo "⚠️ 未安装或未在 PATH 中"
fi

# 3. Gateway Token
echo -n "3. Gateway Token... "
TOKEN=$(grep -o '"token": "[^"]*"' ~/.openclaw/openclaw.json 2>/dev/null | head -1 | sed 's/"token": "//;s/"//')
if [ -n "$TOKEN" ] && [ ${#TOKEN} -ge 32 ]; then
  echo "✅ 已设置（${#TOKEN} 字符）"
elif [ -n "$TOKEN" ]; then
  echo "⚠️ Token 太短（${#TOKEN} 字符），建议 ≥ 32 字符"
else
  echo "❌ 未设置"
fi

# 4. API Key 不在配置文件中（检查是否用环境变量替代）
echo -n "4. API Key 安全... "
if grep -r "sk-" ~/.openclaw/openclaw.json 2>/dev/null | grep -v "\\$" | grep -q "apiKey"; then
  echo "⚠️ openclaw.json 中发现明文 API Key（建议移入环境变量）"
else
  echo "✅ 未在配置文件中发现明文 Key"
fi

# 5. 技能 scripts 检查
echo -n "5. 技能 scripts 检查... "
SCRIPTS=$(find ~/.openclaw -path "*/skills/*/scripts/*" -type f 2>/dev/null | wc -l)
if [ "$SCRIPTS" -gt 0 ]; then
  echo "⚠️ 发现 $SCRIPTS 个技能脚本文件，建议审查"
else
  echo "✅ 无可执行脚本"
fi

# 6. Gateway 公网暴露检查
echo -n "6. Gateway 公网暴露... "
if grep -q '"bind": "loopback"' ~/.openclaw/openclaw.json 2>/dev/null; then
  echo "✅ loopback 绑定，未暴露公网"
elif grep -q '"bind": "lan"' ~/.openclaw/openclaw.json 2>/dev/null; then
  echo "⚠️ LAN 绑定，可能暴露到局域网"
else
  echo "⚠️ 未配置 bind，使用默认值"
fi

# 7. Config 有效性
echo -n "7. 配置文件有效性... "
E:/develop/nodejs/node.exe E:/node_global/node_modules/openclaw/dist/index.js config validate 2>&1 | grep -q "valid"
if [ $? -eq 0 ]; then
  echo "✅ 有效"
else
  echo "❌ 无效 — 运行 openclaw config validate 查看详情"
fi

# 8. 飞书连接状态
echo -n "8. 飞书 Channel... "
if grep -A3 '"feishu"' ~/.openclaw/openclaw.json 2>/dev/null | grep -q '"enabled": true'; then
  echo "✅ 已启用（WebSocket）"
else
  echo "⚠️ 未启用"
fi

# 9. 配对审批
echo -n "9. 配对审批模式... "
echo "✅ v2026.6.1 内置 local-only（远程连接需手动审批）"

echo "===================="
echo "检查完成。❌ 项需要立即修复，⚠️ 项建议关注。"
