# 🚀 跨境运营 AI 团队

基于 **OpenClaw v2026.6.1** 的 6-Agent 跨境电商运营团队，覆盖选品、定价、Listing、推广、客服全链路。

## 架构

```
👤 老板（飞书/WhatsApp/WebChat）
    │
    ▼
🦊 @zhuguan 主管（Orchestrator）
    │
    ├── 🔍 @xuanpin 选品专员  + linkfoxagent（79工具）
    ├── 💰 @dingjia 定价专员
    ├── 📝 @listing Listing专员
    ├── 📈 @tuiguang 推广专员
    └── 🎧 @kefu   客服专员

📡 频道：飞书(WebSocket) | Telegram | WhatsApp | WebChat
⏰ 自动化：8条Cron + 4h心跳 + 频道路由 + n8n Webhook
🛡️ 安全：127.0.0.1绑定 + Token认证 + 本地配对审批
```

## 快速开始

### 1. 前置条件

```bash
# OpenClaw ≥ v2026.1.29
npm install -g openclaw
openclaw --version  # 应 ≥ 2026.6.1

# DeepSeek API Key
# 获取：https://platform.deepseek.com/
```

### 2. 克隆并配置

```bash
git clone https://github.com/<你的用户名>/cross-border-ai-team.git
cd cross-border-ai-team

# 复制配置模板，填入真实值
cp openclaw.json.example ~/.openclaw/openclaw.json
# 编辑 ~/.openclaw/openclaw.json：
#   - 替换 <你的用户名> 为实际路径
#   - 填入 DeepSeek API Key
#   - 填入飞书 App ID / App Secret
#   - 生成 Gateway Token（openssl rand -hex 32）

# 复制 workspace 文件
cp -r workspace/* ~/.openclaw/workspace/
cp -r agents/* ~/.openclaw/agents/

# 配置环境变量
cp .env.example .env
# 编辑 .env，填入真实值后：
#   source .env  （或写入 ~/.bashrc）
```

### 3. 注册 Agent 并启动

```bash
# 注册 6 个 Agent
openclaw agents add zhuguan --workspace ~/.openclaw/agents/zhuguan/workspace
openclaw agents add xuanpin  --workspace ~/.openclaw/agents/xuanpin/workspace
openclaw agents add dingjia  --workspace ~/.openclaw/agents/dingjia/workspace
openclaw agents add listing  --workspace ~/.openclaw/agents/listing/workspace
openclaw agents add tuiguang --workspace ~/.openclaw/agents/tuiguang/workspace
openclaw agents add kefu     --workspace ~/.openclaw/agents/kefu/workspace

# 安装选品技能
openclaw skills install linkfoxagent --agent xuanpin

# 认证 DeepSeek
echo "sk-your-deepseek-key" | openclaw models auth paste-token --provider deepseek

# 启动
openclaw gateway
```

### 4. 验证

```bash
# 运行安全自检
bash security-check.sh

# 测试主管
openclaw agent --agent zhuguan --message "你好，团队状态？"
```

## 文件结构

```
cross-border-ai-team/
├── README.md
├── .gitignore                    # 排除敏感文件
├── .env.example                  # 环境变量模板
├── openclaw.json.example         # 配置模板（占位符）
├── security-check.sh             # 一键安全自检
├── workspace/                    # 全局 workspace
│   ├── AGENTS.md                 # 多Agent协作规则
│   ├── SOUL.md
│   ├── HEARTBEAT.md              # 心跳巡检清单
│   ├── references/
│   │   ├── n8n-shopify-webhook.md
│   │   └── webhook-security.md
│   └── ...（IDENTITY/USER/TOOLS）
├── agents/
│   ├── zhuguan/                  # 主管
│   │   ├── workspace/SOUL.md
│   │   ├── workspace/AGENTS.md
│   │   ├── workspace/HEARTBEAT.md
│   │   └── memory/operations.md  # 运营决策记录
│   ├── xuanpin/                  # 选品
│   │   ├── workspace/SOUL.md
│   │   ├── workspace/skills/linkfoxagent/  # 79工具技能包
│   │   └── memory/products.md   # 产品/竞品/供应商档案
│   ├── dingjia/                  # 定价
│   │   ├── workspace/SOUL.md
│   │   └── memory/pricing.md    # FBA费率/成本基线/汇率
│   ├── listing/                  # Listing
│   │   └── workspace/SOUL.md
│   ├── tuiguang/                 # 推广
│   │   └── workspace/SOUL.md
│   └── kefu/                     # 客服
│       ├── workspace/SOUL.md     # 含WhatsApp自动分类规则
│       └── memory/customer-service.md  # FAQ/退货统计/注意事项
```

## 自动化一览

| 类型 | 任务 | 频率 | Agent |
|------|------|------|-------|
| Cron | poll-amazon-returns | */30 min | @kefu |
| Cron | poll-inventory | 每小时 | @zhuguan |
| Cron | inventory-check | 8:00 | @zhuguan |
| Cron | daily-report | 9:00 | @zhuguan |
| Cron | ads-report | 18:00 | @tuiguang |
| Cron | weekly-competitor | 周一10:00 | @xuanpin |
| Cron | monthly-profit | 每月1日 | @dingjia |
| 💓 | 心跳巡检 | 4h | @zhuguan |
| 🔀 | 频道路由 | 实时 | feishu→zhuguan, whatsapp→kefu |

## 安全

```bash
bash security-check.sh  # 一键检查 9 项安全指标
```

- Gateway 仅绑定 `127.0.0.1`
- Token 认证 + 本地配对审批
- API Key 通过环境变量注入
- 飞书 WebSocket 长连接（不暴露端口）

## 扩展

- **n8n Webhook**：参见 `workspace/references/n8n-shopify-webhook.md`
- **Webhook 安全**：参见 `workspace/references/webhook-security.md`
- **LinkFoxAgent**：79 工具详情见 `agents/xuanpin/workspace/skills/linkfoxagent/SKILL.md`

## License

MIT
