## Description: <br>
LinkFoxAgent helps agents perform cross-border e-commerce research across Amazon, TikTok, eBay, Walmart, Shopee, Ozon, 1688, patent sources, trend tools, image analysis, PDF analysis, real-time web search, Amazon opportunity reporting, and optional Lingxing ERP data workflows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[linkfox-ai](https://clawhub.ai/user/linkfox-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
E-commerce operators, marketplace analysts, and sourcing teams use this skill to research products, competitors, keywords, reviews, policies, trends, patents, suppliers, and marketplace performance across major global commerce platforms. Teams with Lingxing credentials can also query ERP data such as ads, orders, listings, inventory, finance, and FBA records. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill connects to external LinkFoxAgent services and can send task prompts and uploaded images outside the local environment. <br>
Mitigation: Avoid submitting secrets, credentials, sensitive personal data, or private documents in prompts or image uploads; review outputs before sharing. <br>
Risk: Lingxing ERP workflows may access sensitive commerce data and include endpoints that can change ERP state. <br>
Mitigation: Use least-privilege API keys, connect only intended stores, and avoid credentials that can modify orders, listings, inventory, or prices unless that is required. <br>
Risk: The security scan summary reports cached access tokens and recommends review before connecting sensitive commerce accounts. <br>
Mitigation: Clear local output and token files after sensitive runs and rotate credentials if they may have been exposed. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/linkfox-ai/linkfoxagent) <br>
- [LinkFoxAgent Homepage](https://agent.linkfox.com/) <br>
- [Amazon Ads Report Reference](references/amazon-ads-report.md) <br>
- [Amazon Ads Report Types](references/amazon-ads-report-types/index.md) <br>
- [Lingxing ERP Reference](references/lingxing-erp.md) <br>
- [Amazon Frontend Reference](references/amazon-frontend.md) <br>
- [Keepa Reference](references/keepa.md) <br>
- [Patent Research Reference](references/patent.md) <br>
- [Web Search Reference](references/web-search.md) <br>
- [Amazon Ads Reporting API Documentation](https://advertising.amazon.com/API/docs/en-us/guides/reporting/v3/report-types) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, JSON, CSV files, shell commands, configuration guidance] <br>
**Output Format:** [Markdown summaries with optional ShareURL links, local CSV file paths, JSON results, and shell command snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires LINKFOXAGENT_API_KEY; optional Lingxing ERP workflows require least-privilege Lingxing credentials.] <br>

## Skill Version(s): <br>
1.0.18 (source: frontmatter and server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
