# Webhook 安全架构

## 原则

```
外部平台（Shopify/Amazon）
    │
    │  HTTPS + HMAC 签名
    ▼
Nginx 反向代理（HTTPS 终结 + IP 白名单）
    │
    │  http://127.0.0.1:5678
    ▼
n8n Webhook Receiver（仅监听 127.0.0.1）
    │
    │  飞书 Bot API（HTTPS）
    ▼
OpenClaw Gateway（仅监听 127.0.0.1:18789）
```

**Gateway 绝不暴露到公网。** 所有外部流量通过 Nginx → n8n → 飞书 这条链进入。

---

## 1. Gateway 绑定 loopback

```json
// ~/.openclaw/openclaw.json
{
  "gateway": {
    "bind": "loopback"     // 仅 127.0.0.1，不暴露到局域网/公网
  }
}
```

重启后 Gateway 不再监听 `0.0.0.0:18789`，只接受本地连接。

---

## 2. Nginx 反向代理（HTTPS 终结）

只代理 n8n，不代理 Gateway。Gateway 始终走飞书 Channel。

```nginx
# /etc/nginx/sites-available/n8n-webhook

# Shopify/Amazon Webhook 出口 IP 白名单
geo $platform_allowed {
    default 0;

    # Shopify Webhook 出口 IP（定期更新：https://shopify.dev/docs/api/usage/webhooks#ip-addresses）
    23.227.0.0/16    1;
    204.93.0.0/16    1;

    # 你的 n8n 服务器本机
    127.0.0.1        1;
}

server {
    listen 443 ssl http2;
    server_name webhook.你的域名.com;

    ssl_certificate     /etc/letsencrypt/live/webhook.你的域名.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/webhook.你的域名.com/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    # 仅允许 Shopify/Amazon IP
    if ($platform_allowed = 0) {
        return 403;
    }

    location /webhook/ {
        proxy_pass http://127.0.0.1:5678;   # n8n 也只绑 127.0.0.1
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # 传递原始 body（HMAC 验证需要）
        proxy_pass_request_body on;
    }
}
```

### 申请免费 HTTPS 证书

```bash
# Let's Encrypt
sudo certbot certonly --nginx -d webhook.你的域名.com

# 自动续期
sudo certbot renew --dry-run
```

---

## 3. n8n 侧 IP 白名单验证

在 n8n workflow 的 Function 节点中加一层二次校验：

```javascript
// n8n Function: IP 白名单二次验证
const ALLOWED_IPS = [
  '23.227.0.0/16',   // Shopify
  '54.xxx.xxx.0/24',  // Amazon SNS (查 AWS IP ranges)
];

const clientIp = $input.first().json.headers['x-real-ip'] 
              || $input.first().json.headers['x-forwarded-for'];

// 简化版：至少验证请求来源在允许范围内
// 生产环境使用 ip-range-check 库做精确 CIDR 匹配
const isAllowed = ALLOWED_IPS.some(range => {
  // 用 netmask 或 ip-range-check npm 包做 CIDR 匹配
  return true; // 替换为实际验证逻辑
});

if (!isAllowed) {
  throw new Error(`IP ${clientIp} 不在白名单中`);
}
```

---

## 4. Shopify Webhook IP 地址

来源：https://shopify.dev/docs/api/usage/webhooks#ip-addresses

```
23.227.32.0/19
```

> ⚠️ Shopify 可能更新 IP 段。订阅 Shopify Changelog 或在 n8n 中设置定期检查任务。

---

## 5. 端到端安全清单

| 层 | 措施 | 状态 |
|----|------|------|
| 传输 | HTTPS（Let's Encrypt） | 需配置 |
| 网关 | Gateway bind=loopback | ✅ 已配置 |
| 签名 | Shopify HMAC-SHA256 / Amazon SNS 签名 | n8n 中验证 |
| 白名单 | Nginx geo 模块限制来源 IP | 需配置 |
| 时效 | 检查 webhook 时间戳防重放 | n8n Function |
| 重放 | n8n Webhook 去重（订单号去重） | n8n Function |
| 密钥 | 所有 Secret 走环境变量，不硬编码 | ✅ `${ENV_VAR}` |
| 最小权限 | Gateway 不暴露公网，所有外部请求通过飞书 Channel | ✅ |
