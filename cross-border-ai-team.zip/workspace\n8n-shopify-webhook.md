# n8n Shopify Webhook 配置

## 架构

```
Shopify ──HMAC-SHA256──→ n8n Webhook ──金额>$100?──→ 飞书机器人 ──→ OpenClaw @zhuguan
                              │
                              └── 否 → Gmail/SendGrid 发标准模板
                              │
                              └── 更新 Google Sheets
```

---

## Step 1: Shopify 侧配置

1. Shopify Admin → Settings → Notifications → Webhooks
2. Create webhook:
   - Event: `Order creation`
   - Format: JSON
   - URL: `https://<你的n8n域名>/webhook/shopify/orders`
   - Webhook API version: `2024-01`
3. 记下 **Webhook signing secret**（Shopify 自动生成的一串字符）
4. 填入 n8n 环境变量：`SHOPIFY_WEBHOOK_SECRET`

---

## Step 2: n8n Workflow 配置

### Node 1: Webhook 触发器

```json
{
  "name": "Shopify Webhook",
  "type": "n8n-nodes-base.webhook",
  "parameters": {
    "path": "shopify/orders",
    "responseMode": "responseNode",
    "options": {
      "rawBody": true
    }
  }
}
```

**关键：** `rawBody: true` 是 HMAC 验证的前提。Shopify 对原始 body 做签名，不能 parse 之后再验证。

### Node 2: HMAC 签名验证（Function 节点）

```javascript
// 从 headers 获取 Shopify HMAC
const hmacHeader = $input.first().json.headers['x-shopify-hmac-sha256'];
const rawBody = $input.first().json.body; // rawBody: true 保证是原始字符串
const secret = $env.SHOPIFY_WEBHOOK_SECRET;

// Node.js crypto HMAC-SHA256 验证
const crypto = require('crypto');
const computedHmac = crypto
  .createHmac('sha256', secret)
  .update(rawBody, 'utf8')
  .digest('base64');

const valid = crypto.timingSafeEqual(
  Buffer.from(hmacHeader),
  Buffer.from(computedHmac)
);

if (!valid) {
  throw new Error('HMAC 签名验证失败 — 请求可能是伪造的');
}

// 验证通过，解析 JSON 传给下游
return JSON.parse(rawBody);
```

### Node 2 (备选): n8n 原生 Webhook 节点验证

n8n ≥1.0 版本的 Webhook 节点内置 `Secret` 字段：
- `authentication`: "Header Auth"
- `headerAuthType`: 选 "HMAC-SHA256"
- 填入 `$env.SHOPIFY_WEBHOOK_SECRET`

### Node 3: 提取订单数据（Function）

```javascript
const order = $input.first().json;

return {
  orderId: order.id,
  orderNumber: order.order_number,
  totalPrice: parseFloat(order.total_price),
  currency: order.currency,
  customerName: `${order.customer?.first_name ?? ''} ${order.customer?.last_name ?? ''}`.trim(),
  customerEmail: order.customer?.email,
  customerPhone: order.customer?.phone,
  shippingAddress: {
    country: order.shipping_address?.country,
    province: order.shipping_address?.province,
    city: order.shipping_address?.city,
    address1: order.shipping_address?.address1,
    zip: order.shipping_address?.zip
  },
  items: order.line_items.map(item => ({
    sku: item.sku,
    title: item.title,
    quantity: item.quantity,
    price: parseFloat(item.price)
  })),
  isVip: parseFloat(order.total_price) > 100
};
```

### Node 4: IF 分支 — 金额 > $100?

```
条件：{{ $json.isVip === true }}
  ├── true  → Node 5: 发飞书消息给 @zhuguan
  └── false → Node 7: 发标准感谢邮件
```

### Node 5: VIP → 飞书机器人（HTTP Request）

```json
{
  "name": "通知飞书 (VIP订单)",
  "type": "n8n-nodes-base.httpRequest",
  "parameters": {
    "method": "POST",
    "url": "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id",
    "authentication": "genericCredentialType",
    "genericAuthType": "httpHeaderAuth",
    "headerAuth": {
      "name": "Authorization",
      "value": "Bearer {{ $env.FEISHU_BOT_TOKEN }}"
    },
    "sendBody": true,
    "bodyParameters": {
      "parameters": [
        {
          "name": "receive_id",
          "value": "<你的飞书用户OpenID>"
        },
        {
          "name": "msg_type",
          "value": "text"
        },
        {
          "name": "content",
          "value": "{\"text\":\"🔔 VIP 订单 #{{ $json.orderNumber }}\\n客户：{{ $json.customerName }}\\n金额：${{ $json.totalPrice }}\\n商品：{{ $json.items.map(i => i.title).join(', ') }}\\n国家：{{ $json.shippingAddress.country }}\\n\\n@zhuguan 请生成个性化VIP感谢邮件。\"}"
        }
      ]
    }
  }
}
```

### Node 6: 等待 OpenClaw 返回（Webhook Response）

```json
{
  "name": "返回 n8n 响应",
  "type": "n8n-nodes-base.respondToWebhook",
  "parameters": {
    "respondWith": "json",
    "responseBody": "={\"status\": \"ok\", \"order\": \"{{ $json.orderNumber }}\"}"
  }
}
```

### Node 7: 普通订单 → 标准邮件模板（Gmail / SendGrid）

```
使用 n8n Gmail 节点 或 SendGrid 节点
模板：
---
Subject: Thank you for your order #{{ $json.orderNumber }}!

Hi {{ $json.customerName }},

Thank you for shopping with us! 

Your order #{{ $json.orderNumber }} is being processed.
[商品清单：{{ $json.items.map(i => `${i.title} x${i.quantity}`).join(', ') }}]

We'll notify you once it ships.

Best regards,
[Your Store Name]
---
```

### Node 8: 更新 Google Sheets

```json
{
  "name": "记录到 Google Sheets",
  "type": "n8n-nodes-base.googleSheets",
  "parameters": {
    "operation": "append",
    "sheetId": "<你的GoogleSheetID>",
    "range": "Orders!A:J",
    "columns": [
      "{{ $json.orderNumber }}",
      "{{ $json.customerName }}",
      "{{ $json.customerEmail }}",
      "{{ $json.totalPrice }}",
      "{{ $json.shippingAddress.country }}",
      "{{ $json.isVip ? 'VIP' : '普通' }}",
      "{{ new Date().toISOString() }}"
    ]
  }
}
```

---

## Step 3: 环境变量

在 n8n 中配置以下环境变量（docker-compose 或 .env）：

```bash
SHOPIFY_WEBHOOK_SECRET=shpss_xxxxxxxxxxxxx    # Shopify 生成的签名密钥
FEISHU_BOT_TOKEN=t-xxxxxxxxxxxxx               # 飞书机器人访问令牌
```

> **飞书 Bot Token 获取方式：** 飞书开放平台 → 你的应用 → 凭证与基础信息 → 获取 Tenant Access Token 或使用 Bot Token。

---

## Step 4: 测试

1. Shopify 后台 → Webhooks → 点击刚创建的 webhook → "Send test notification"
2. 查看 n8n 执行日志，确认 HMAC 验证通过
3. 模拟不同金额的订单验证分支逻辑
4. 确认飞书收到 VIP 订单消息，@zhuguan 开始处理

---

## 完整节点流程图

```
[Shopify Webhook] → [HMAC 验证] → [提取订单] → [IF $>100?]
                                                      ├── true → [飞书→@zhuguan]
                                                      └── false → [标准邮件模板]
                                                   [Google Sheets]
                                                   [Webhook Response 200]
```
