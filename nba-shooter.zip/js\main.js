﻿import * as THREE from "three";
import { initScene, getScene, getCamera, getRenderer, getBall, getHoopPosition, getRimRadius, getBallRadius } from "./scene.js";
import { updatePhysics, setOnScore, setOnMiss, resetBall, isBallActive } from "./physics.js";
import { initShooting, updateCharging, setShootingPosition, getShootingPosition, setCanShoot, getIsCharging, getPower, getMouseDownPos, setOnShotTaken } from "./shooting.js";
import {
  initUI, showMenu, hideMenu, showHUD, hideHUD,
  updateTimer, updateScore, showResult, showCountdown,
  showPowerRing, hidePowerRing, showFloatingText, showScreenShake,
  setHUDPracticeMode, setHUDChallengeMode,
  getSelectedTeam, getSelectedMode,
  setOnStartGame, setOnReturnMenu
} from "./ui.js";

const GameState = { MENU: "menu", COUNTDOWN: "countdown", PLAYING: "playing", RESULT: "result" };
let state = GameState.MENU;

// Game data
let score = 0;
let combo = 0;
let maxCombo = 0;
let totalShots = 0;
let totalMakes = 0;
let timeRemaining = 60;
let mode = "challenge";
let lastShotTime = 0;
let clock;

// Shooting positions for practice mode
const practiceSpots = [
  new THREE.Vector3(0, 5.5, 0),       // free throw
  new THREE.Vector3(-5, 5.5, -3),     // left wing
  new THREE.Vector3(5, 5.5, -3),      // right wing
];
let currentSpotIndex = 0;

function resetGameStats() {
  score = 0;
  combo = 0;
  maxCombo = 0;
  totalShots = 0;
  totalMakes = 0;
  timeRemaining = 60;
  lastShotTime = 0;
  currentSpotIndex = 0;
}

function startGame(gameMode, teamId) {
  mode = gameMode;
  resetGameStats();

  // Set practice spot
  const spot = mode === "practice" ? practiceSpots[0] : practiceSpots[0];
  setShootingPosition(spot);
  resetBall(spot);

  // Set ball visibility for aiming reference
  const ball = getBall();
  if (ball) {
    ball.position.copy(spot);
    ball.visible = true;
  }

  // Show HUD
  hideMenu();
  showHUD();

  if (mode === "practice") {
    setHUDPracticeMode();
  } else {
    setHUDChallengeMode();
  }

  updateScore(score, combo, totalShots, totalMakes);
  updateTimer(timeRemaining);

  // Countdown then start
  state = GameState.COUNTDOWN;
  setCanShoot(false);
  showCountdown(3, () => {
    state = GameState.PLAYING;
    setCanShoot(true);
    if (mode === "challenge") {
      startTimer();
    }
  });
}

function startTimer() {
  clock = setInterval(() => {
    timeRemaining -= 0.1;
    updateTimer(timeRemaining);
    if (timeRemaining <= 0) {
      endGame();
    }
  }, 100);
}

function endGame() {
  state = GameState.RESULT;
  setCanShoot(false);
  if (clock) clearInterval(clock);
  hideHUD();
  showResult({
    score,
    totalShots,
    totalMakes,
    pct: totalShots > 0 ? Math.round((totalMakes / totalShots) * 100) : 0,
    maxCombo
  });
}

function onScore() {
  if (state !== GameState.PLAYING) return;

  totalShots++;
  totalMakes++;
  combo++;
  if (combo > maxCombo) maxCombo = combo;

  // Scoring: 2 points for free throw area
  const pts = 2;
  const comboBonus = combo >= 3 ? combo : 1;
  score += pts * comboBonus;

  updateScore(score, combo, totalShots, totalMakes);

  // Visual feedback
  const renderer = getRenderer();
  if (renderer) {
    const rect = renderer.domElement.getBoundingClientRect();
    const cx = rect.width / 2;
    const cy = rect.height * 0.35;
    const text = combo >= 3 ? `+${pts * comboBonus} 🔥` : `+${pts}`;
    const color = combo >= 3 ? "#ff5722" : "#ff9800";
    showFloatingText(cx, cy, text, color, combo >= 5 ? 36 : 28);
  }
  showScreenShake();

  // Reset ball for next shot
  setTimeout(() => {
    if (state === GameState.PLAYING) {
      const spot = getCurrentSpot();
      setShootingPosition(spot);
    }
  }, 600);
}

function onMiss() {
  if (state !== GameState.PLAYING) return;

  totalShots++;
  combo = 0;
  updateScore(score, combo, totalShots, totalMakes);

  // Reset for next shot
  setTimeout(() => {
    if (state === GameState.PLAYING) {
      const spot = getCurrentSpot();
      setShootingPosition(spot);
    }
  }, 800);
}

function getCurrentSpot() {
  if (mode === "practice") {
    return practiceSpots[currentSpotIndex];
  }
  return practiceSpots[0]; // challenge always free throw
}

// Practice mode: click to cycle shooting spots
function setupPracticeSpotCycling() {
  document.addEventListener("keydown", (e) => {
    if (state !== GameState.PLAYING || mode !== "practice") return;
    if (isBallActive()) return;

    if (e.key === "1") currentSpotIndex = 0;
    else if (e.key === "2") currentSpotIndex = 1;
    else if (e.key === "3") currentSpotIndex = 2;
    else if (e.key === "ArrowRight") currentSpotIndex = (currentSpotIndex + 1) % 3;
    else if (e.key === "ArrowLeft") currentSpotIndex = (currentSpotIndex - 1 + 3) % 3;
    else return;

    const spot = practiceSpots[currentSpotIndex];
    resetBall(spot);
    setShootingPosition(spot);

    const ball = getBall();
    if (ball) {
      ball.position.copy(spot);
      ball.visible = true;
    }

    // Show spot indicator
    const renderer = getRenderer();
    if (renderer) {
      const rect = renderer.domElement.getBoundingClientRect();
      const labels = ["罚球线", "左翼", "右翼"];
      showFloatingText(rect.width / 2, rect.height * 0.6, labels[currentSpotIndex], "#fff", 18);
    }
  });
}

function onShotTakenCallback() {
  lastShotTime = performance.now();
  // Camera subtle zoom on shot
  const camera = getCamera();
  if (camera) {
    // Slight camera shake
    const origZ = camera.position.z;
    camera.position.z += 0.2;
    setTimeout(() => { camera.position.z = origZ; }, 100);
  }
}

function returnToMenu() {
  state = GameState.MENU;
  setCanShoot(false);
  if (clock) clearInterval(clock);
  hideHUD();
  resetGameStats();

  // Reset ball
  resetBall(practiceSpots[0]);
  const ball = getBall();
  if (ball) ball.visible = false;

  showMenu();
}

// Main loop
function gameLoop(time) {
  requestAnimationFrame(gameLoop);

  const dt = Math.min(0.05, (time - (gameLoop._lastTime || time)) / 1000);
  gameLoop._lastTime = time;

  // Update charging
  updateCharging(dt);

  // Update physics
  updatePhysics(dt);

  // Update power ring display
  if (getIsCharging() && state === GameState.PLAYING) {
    const renderer = getRenderer();
    if (renderer) {
      const rect = renderer.domElement.getBoundingClientRect();
      const pos = getMouseDownPos();
      showPowerRing(pos.x, pos.y, getPower(), 100);
    }
  } else {
    hidePowerRing();
  }

  // Render
  const scene = getScene();
  const camera = getCamera();
  const renderer = getRenderer();
  if (scene && camera && renderer) {
    renderer.render(scene, camera);
  }
}

export function init() {
  const container = document.getElementById("game-container");
  if (!container) {
    console.error("Game container not found");
    return;
  }

  // Init 3D scene
  initScene(container);
  const renderer = getRenderer();

  // Init UI
  initUI(container);

  // Init shooting on canvas
  if (renderer) {
    initShooting(renderer.domElement);
  }

  // Setup callbacks
  setOnScore(onScore);
  setOnMiss(onMiss);
  setOnStartGame(startGame);
  setOnReturnMenu(returnToMenu);
  setOnShotTaken(onShotTakenCallback);

  // Practice spot cycling
  setupPracticeSpotCycling();

  // Show menu
  showMenu();

  // Start game loop
  gameLoop._lastTime = performance.now();
  requestAnimationFrame(gameLoop);
}

// Auto-init when module loads
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
