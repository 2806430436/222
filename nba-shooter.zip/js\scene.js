﻿import * as THREE from "three";

const HOOP_POSITION = { x: 0, y: 10, z: -15 };
const RIM_RADIUS = 0.75;
const BALL_RADIUS = 0.38;
const COURT_HALF_LENGTH = 20;
const COURT_HALF_WIDTH = 15;

let scene, camera, renderer;
let court, backboard, rim, netGroup, ball;
let directionalLight, ambientLight;

export function getHoopPosition() {
  return new THREE.Vector3(HOOP_POSITION.x, HOOP_POSITION.y, HOOP_POSITION.z);
}

export function getRimRadius() {
  return RIM_RADIUS;
}

export function getBallRadius() {
  return BALL_RADIUS;
}

export function getScene() { return scene; }
export function getCamera() { return camera; }
export function getRenderer() { return renderer; }
export function getBall() { return ball; }
export function getRim() { return rim; }
export function getBackboard() { return backboard; }

function createCourt() {
  // Main floor
  const floorGeo = new THREE.PlaneGeometry(COURT_HALF_WIDTH * 2, COURT_HALF_LENGTH * 2);
  const floorMat = new THREE.MeshStandardMaterial({
    color: 0xc49a6c,
    roughness: 0.5,
    metalness: 0.05
  });
  const floor = new THREE.Mesh(floorGeo, floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(0, 0, -COURT_HALF_LENGTH / 2);
  floor.receiveShadow = true;
  scene.add(floor);

  // Out of bounds / sideline markings
  const paintMat = new THREE.MeshStandardMaterial({ color: 0xb8865a, roughness: 0.6 });
  // The key/paint area
  const paintGeo = new THREE.PlaneGeometry(5, 6);
  const paint = new THREE.Mesh(paintGeo, paintMat);
  paint.rotation.x = -Math.PI / 2;
  paint.position.set(0, 0.005, -HOOP_POSITION.z + 3);
  scene.add(paint);

  // Three-point arc (simplified as a semi-circle line)
  const arcPoints = [];
  const arcRadius = 7;
  const arcCenterZ = HOOP_POSITION.z;
  for (let i = 0; i <= 64; i++) {
    const angle = -Math.PI / 2 + (Math.PI * i) / 64;
    arcPoints.push(new THREE.Vector3(
      Math.cos(angle) * arcRadius,
      0.01,
      arcCenterZ + Math.sin(angle) * arcRadius
    ));
  }
  const arcGeo = new THREE.BufferGeometry().setFromPoints(arcPoints);
  const arcLine = new THREE.Line(arcGeo, new THREE.LineBasicMaterial({ color: 0xffffff }));
  scene.add(arcLine);

  // Free throw line
  const ftLineGeo = new THREE.PlaneGeometry(5, 0.1);
  const ftLineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const ftLine = new THREE.Mesh(ftLineGeo, ftLineMat);
  ftLine.rotation.x = -Math.PI / 2;
  ftLine.position.set(0, 0.006, 0);
  scene.add(ftLine);

  // Center court line
  const centerGeo = new THREE.PlaneGeometry(COURT_HALF_WIDTH * 2, 0.15);
  const centerMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const centerLine = new THREE.Mesh(centerGeo, centerMat);
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.set(0, 0.004, 5);
  scene.add(centerLine);

  // Wood grain subtle lines
  for (let i = -14; i <= 14; i += 2.8) {
    const grainGeo = new THREE.PlaneGeometry(0.08, COURT_HALF_LENGTH * 2);
    const grainMat = new THREE.MeshBasicMaterial({ color: 0xb08050, transparent: true, opacity: 0.3 });
    const grain = new THREE.Mesh(grainGeo, grainMat);
    grain.rotation.x = -Math.PI / 2;
    grain.position.set(i, 0.007, -COURT_HALF_LENGTH / 2);
    scene.add(grain);
  }
}

function createHoop() {
  // Backboard
  const bbGeo = new THREE.BoxGeometry(6, 3.5, 0.2);
  const bbMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.3,
    metalness: 0.1,
    transparent: true,
    opacity: 0.85
  });
  backboard = new THREE.Mesh(bbGeo, bbMat);
  backboard.position.set(0, HOOP_POSITION.y + 0.5, HOOP_POSITION.z + 0.5);
  backboard.castShadow = true;
  scene.add(backboard);

  // Backboard target square
  const squareGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.8, 1.2, 0.21));
  const squareLine = new THREE.LineSegments(squareGeo, new THREE.LineBasicMaterial({ color: 0xff0000 }));
  squareLine.position.copy(backboard.position);
  squareLine.position.z += 0.12;
  scene.add(squareLine);

  // Rim (torus)
  const rimGeo = new THREE.TorusGeometry(RIM_RADIUS, 0.08, 16, 32);
  const rimMat = new THREE.MeshStandardMaterial({
    color: 0xff4500,
    roughness: 0.3,
    metalness: 0.7
  });
  rim = new THREE.Mesh(rimGeo, rimMat);
  rim.rotation.x = Math.PI / 2;
  rim.position.set(0, HOOP_POSITION.y, HOOP_POSITION.z);
  rim.castShadow = true;
  scene.add(rim);

  // Net (simplified cone)
  netGroup = new THREE.Group();
  const netGeo = new THREE.CylinderGeometry(0.15, RIM_RADIUS - 0.05, 1.8, 16, 4, true);
  const netMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.8,
    metalness: 0,
    transparent: true,
    opacity: 0.5,
    side: THREE.DoubleSide
  });
  const netMesh = new THREE.Mesh(netGeo, netMat);
  netMesh.position.y = -0.9;
  netGroup.add(netMesh);
  netGroup.position.set(0, HOOP_POSITION.y, HOOP_POSITION.z);
  scene.add(netGroup);

  // Pole
  const poleGeo = new THREE.CylinderGeometry(0.3, 0.3, HOOP_POSITION.y - 1.5, 8);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x444444, roughness: 0.5, metalness: 0.6 });
  const pole = new THREE.Mesh(poleGeo, poleMat);
  pole.position.set(0, (HOOP_POSITION.y - 1.5) / 2, HOOP_POSITION.z + 1.8);
  pole.castShadow = true;
  scene.add(pole);
}

function createBall() {
  const ballGeo = new THREE.SphereGeometry(BALL_RADIUS, 32, 32);

  // Create basketball texture programmatically using canvas
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext("2d");

  // Orange base
  ctx.fillStyle = "#e8751a";
  ctx.fillRect(0, 0, 512, 256);

  // Black lines - horizontal center line
  ctx.strokeStyle = "#1a1a1a";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(0, 128);
  ctx.lineTo(512, 128);
  ctx.stroke();

  // Vertical center line
  ctx.beginPath();
  ctx.moveTo(256, 0);
  ctx.lineTo(256, 256);
  ctx.stroke();

  // Curved lines (simplified arcs)
  ctx.lineWidth = 3;
  // Left arc
  ctx.beginPath();
  ctx.ellipse(128, 128, 100, 80, 0, 0, Math.PI * 2);
  ctx.stroke();
  // Right arc
  ctx.beginPath();
  ctx.ellipse(384, 128, 100, 80, 0, 0, Math.PI * 2);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapU = THREE.RepeatWrapping;

  const ballMat = new THREE.MeshStandardMaterial({
    map: texture,
    roughness: 0.5,
    metalness: 0.05
  });
  ball = new THREE.Mesh(ballGeo, ballMat);
  ball.castShadow = true;
  ball.position.set(0, BALL_RADIUS + 0.02, 0);
  ball.visible = false;
  scene.add(ball);

  return ball;
}

function createLights() {
  ambientLight = new THREE.AmbientLight(0x404060, 0.8);
  scene.add(ambientLight);

  directionalLight = new THREE.DirectionalLight(0xffffff, 1.5);
  directionalLight.position.set(5, 20, -5);
  directionalLight.castShadow = true;
  directionalLight.shadow.mapSize.width = 1024;
  directionalLight.shadow.mapSize.height = 1024;
  directionalLight.shadow.camera.near = 0.5;
  directionalLight.shadow.camera.far = 60;
  directionalLight.shadow.camera.left = -20;
  directionalLight.shadow.camera.right = 20;
  directionalLight.shadow.camera.top = 20;
  directionalLight.shadow.camera.bottom = -20;
  scene.add(directionalLight);

  // Rim light for atmosphere
  const pointLight = new THREE.PointLight(0xff9944, 0.5, 10);
  pointLight.position.set(0, HOOP_POSITION.y, HOOP_POSITION.z);
  scene.add(pointLight);
}

export function initScene(container) {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x1a1a2e);
  scene.fog = new THREE.Fog(0x1a1a2e, 30, 60);

  const aspect = container.clientWidth / container.clientHeight;
  camera = new THREE.PerspectiveCamera(55, aspect, 0.5, 80);
  camera.position.set(0, 6.5, 5);
  camera.lookAt(HOOP_POSITION.x, HOOP_POSITION.y, HOOP_POSITION.z);

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  createLights();
  createCourt();
  createHoop();
  createBall();

  // Ground-level grid for spatial reference
  const gridHelper = new THREE.PolarGridHelper(25, 32, 24, 64, 0x444444, 0x333333);
  gridHelper.position.y = 0.008;
  scene.add(gridHelper);

  window.addEventListener("resize", () => {
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });

  return { scene, camera, renderer, ball };
}
