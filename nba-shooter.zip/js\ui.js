﻿import { NBA_TEAMS, getTeamById } from "./nba-data.js";

let uiRoot;
let menuPanel, hudPanel, resultPanel, countdownOverlay;

// HUD elements
let timerEl, scoreEl, comboEl, accuracyEl, shotCountEl;
// Power indicator
let powerRing;
// Floating text container
let floatContainer;

let selectedTeamId = "LAL";
let selectedMode = "challenge"; // "challenge" | "practice"
let onStartGame = null;
let onReturnMenu = null;

export function getSelectedTeam() { return getTeamById(selectedTeamId); }
export function getSelectedMode() { return selectedMode; }

export function setOnStartGame(cb) { onStartGame = cb; }
export function setOnReturnMenu(cb) { onReturnMenu = cb; }

export function initUI(container) {
  uiRoot = document.createElement("div");
  uiRoot.id = "ui-root";
  uiRoot.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:10;font-family:'Segoe UI',sans-serif;";
  container.appendChild(uiRoot);

  floatContainer = document.createElement("div");
  floatContainer.id = "float-container";
  floatContainer.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;";
  uiRoot.appendChild(floatContainer);

  createMenuPanel();
  createHUDPanel();
  createResultPanel();
  createCountdownOverlay();
  createPowerRing();
}

function createMenuPanel() {
  menuPanel = document.createElement("div");
  menuPanel.id = "menu-panel";
  menuPanel.style.cssText = `
    position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
    background:rgba(10,10,30,0.92);border-radius:16px;padding:32px 40px;
    color:#fff;text-align:center;min-width:520px;max-height:85vh;overflow-y:auto;
    pointer-events:auto;box-shadow:0 8px 40px rgba(0,0,0,0.5);
    border:1px solid rgba(255,255,255,0.1);
  `;

  const title = document.createElement("h1");
  title.textContent = "🏀 NBA 投篮街机";
  title.style.cssText = "margin:0 0 8px;font-size:28px;font-weight:700;letter-spacing:1px;";
  menuPanel.appendChild(title);

  const subtitle = document.createElement("p");
  subtitle.textContent = "选择你的球队，开始投篮吧！";
  subtitle.style.cssText = "margin:0 0 24px;color:#aaa;font-size:14px;";
  menuPanel.appendChild(subtitle);

  // Team grid
  const teamGrid = document.createElement("div");
  teamGrid.style.cssText = "display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:24px;";
  NBA_TEAMS.forEach(team => {
    const btn = document.createElement("button");
    btn.textContent = team.id;
    btn.title = `${team.name} - ${team.player}`;
    btn.style.cssText = `
      padding:10px 4px;border-radius:8px;border:2px solid transparent;
      background:${team.primary};color:#fff;font-size:11px;font-weight:700;
      cursor:pointer;transition:all 0.15s;letter-spacing:0.5px;
    `;
    if (team.id === selectedTeamId) {
      btn.style.borderColor = "#fff";
      btn.style.boxShadow = `0 0 12px ${team.primary}`;
    }
    btn.addEventListener("click", () => {
      selectedTeamId = team.id;
      refreshTeamSelection();
      updateHUDTeam();
    });
    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "scale(1.08)";
      btn.style.zIndex = "2";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "scale(1)";
      btn.style.zIndex = "1";
    });
    teamGrid.appendChild(btn);
  });
  menuPanel.appendChild(teamGrid);

  // Selected team info
  const teamInfo = document.createElement("div");
  teamInfo.id = "team-info";
  teamInfo.style.cssText = "margin-bottom:20px;font-size:14px;color:#ccc;";
  menuPanel.appendChild(teamInfo);
  refreshTeamSelection();

  // Mode buttons
  const modeRow = document.createElement("div");
  modeRow.style.cssText = "display:flex;gap:12px;justify-content:center;margin-bottom:20px;";
  ["challenge", "practice"].forEach(mode => {
    const btn = document.createElement("button");
    btn.id = `mode-${mode}`;
    btn.textContent = mode === "challenge" ? "⏱ 限时挑战" : "🎯 自由练习";
    btn.style.cssText = `
      padding:10px 24px;border-radius:10px;border:2px solid rgba(255,255,255,0.2);
      background:transparent;color:#fff;font-size:15px;font-weight:600;
      cursor:pointer;transition:all 0.15s;
    `;
    if (mode === selectedMode) {
      btn.style.background = "rgba(255,255,255,0.15)";
      btn.style.borderColor = "#fff";
    }
    btn.addEventListener("click", () => {
      selectedMode = mode;
      document.getElementById("mode-challenge").style.background = "transparent";
      document.getElementById("mode-challenge").style.borderColor = "rgba(255,255,255,0.2)";
      document.getElementById("mode-practice").style.background = "transparent";
      document.getElementById("mode-practice").style.borderColor = "rgba(255,255,255,0.2)";
      btn.style.background = "rgba(255,255,255,0.15)";
      btn.style.borderColor = "#fff";
    });
    modeRow.appendChild(btn);
  });
  menuPanel.appendChild(modeRow);

  // Start button
  const startBtn = document.createElement("button");
  startBtn.textContent = "开始比赛";
  startBtn.style.cssText = `
    padding:14px 60px;border-radius:12px;border:none;
    background:linear-gradient(135deg,#ff5722,#e91e63);color:#fff;
    font-size:18px;font-weight:700;cursor:pointer;letter-spacing:1px;
    transition:transform 0.15s,box-shadow 0.15s;
    box-shadow:0 4px 20px rgba(255,87,34,0.4);
  `;
  startBtn.addEventListener("mouseenter", () => {
    startBtn.style.transform = "scale(1.04)";
    startBtn.style.boxShadow = "0 6px 30px rgba(255,87,34,0.6)";
  });
  startBtn.addEventListener("mouseleave", () => {
    startBtn.style.transform = "scale(1)";
    startBtn.style.boxShadow = "0 4px 20px rgba(255,87,34,0.4)";
  });
  startBtn.addEventListener("click", () => {
    if (onStartGame) onStartGame(selectedMode, selectedTeamId);
  });
  menuPanel.appendChild(startBtn);

  uiRoot.appendChild(menuPanel);
}

function refreshTeamSelection() {
  const team = getTeamById(selectedTeamId);
  const info = document.getElementById("team-info");
  if (info && team) {
    info.innerHTML = `<span style="color:${team.primary};font-weight:700;">${team.name}</span> — ${team.player}`;
  }

  // Update team button highlights
  const buttons = menuPanel.querySelectorAll("button");
  buttons.forEach(btn => {
    const teamData = NBA_TEAMS.find(t => t.id === btn.textContent);
    if (teamData) {
      if (teamData.id === selectedTeamId) {
        btn.style.borderColor = "#fff";
        btn.style.boxShadow = `0 0 12px ${teamData.primary}`;
        btn.style.transform = "scale(1.05)";
      } else {
        btn.style.borderColor = "transparent";
        btn.style.boxShadow = "none";
        btn.style.transform = "scale(1)";
      }
    }
  });
}

function updateHUDTeam() {
  if (!hudPanel) return;
  const team = getTeamById(selectedTeamId);
  const teamIndicator = document.getElementById("hud-team");
  if (teamIndicator && team) {
    teamIndicator.style.color = team.primary;
    teamIndicator.textContent = team.id;
  }
}

function createHUDPanel() {
  hudPanel = document.createElement("div");
  hudPanel.id = "hud-panel";
  hudPanel.style.cssText = `
    position:absolute;top:0;left:0;right:0;padding:16px 24px;
    display:none;justify-content:space-between;align-items:center;
    background:linear-gradient(180deg,rgba(0,0,0,0.7) 0%,transparent 100%);
    pointer-events:none;
  `;

  // Left: team
  const left = document.createElement("div");
  left.style.cssText = "display:flex;align-items:center;gap:12px;";
  const teamEl = document.createElement("span");
  teamEl.id = "hud-team";
  teamEl.style.cssText = "font-size:20px;font-weight:800;letter-spacing:1px;";
  left.appendChild(teamEl);

  const playerEl = document.createElement("span");
  playerEl.id = "hud-player";
  playerEl.style.cssText = "font-size:13px;color:#aaa;";
  left.appendChild(playerEl);
  hudPanel.appendChild(left);

  // Center: timer
  const center = document.createElement("div");
  center.style.cssText = "text-align:center;";
  timerEl = document.createElement("div");
  timerEl.id = "hud-timer";
  timerEl.style.cssText = "font-size:36px;font-weight:800;font-variant-numeric:tabular-nums;color:#fff;";
  timerEl.textContent = "60";
  center.appendChild(timerEl);

  const timerLabel = document.createElement("div");
  timerLabel.style.cssText = "font-size:11px;color:#888;text-transform:uppercase;letter-spacing:2px;";
  timerLabel.textContent = "剩余时间";
  center.appendChild(timerLabel);
  hudPanel.appendChild(center);

  // Right: score + accuracy
  const right = document.createElement("div");
  right.style.cssText = "display:flex;flex-direction:column;align-items:flex-end;gap:4px;";
  scoreEl = document.createElement("div");
  scoreEl.id = "hud-score";
  scoreEl.style.cssText = "font-size:28px;font-weight:800;color:#ff9800;";
  scoreEl.textContent = "0";
  right.appendChild(scoreEl);

  const statsRow = document.createElement("div");
  statsRow.style.cssText = "display:flex;gap:16px;font-size:12px;color:#999;";

  accuracyEl = document.createElement("span");
  accuracyEl.id = "hud-accuracy";
  accuracyEl.textContent = "—";
  statsRow.appendChild(accuracyEl);

  shotCountEl = document.createElement("span");
  shotCountEl.id = "hud-shots";
  shotCountEl.textContent = "0/0";
  statsRow.appendChild(shotCountEl);

  comboEl = document.createElement("span");
  comboEl.id = "hud-combo";
  comboEl.style.cssText = "color:#ff5722;font-weight:700;display:none;";
  comboEl.textContent = "";
  statsRow.appendChild(comboEl);

  right.appendChild(statsRow);
  hudPanel.appendChild(right);

  uiRoot.appendChild(hudPanel);
}

function createPowerRing() {
  powerRing = document.createElement("div");
  powerRing.id = "power-ring";
  powerRing.style.cssText = `
    position:absolute;width:80px;height:80px;border-radius:50%;
    border:3px solid rgba(255,255,255,0.3);
    display:none;pointer-events:none;
    transform:translate(-50%,-50%);
  `;

  const inner = document.createElement("div");
  inner.id = "power-inner";
  inner.style.cssText = `
    position:absolute;top:4px;left:4px;right:4px;bottom:4px;border-radius:50%;
    background:rgba(255,87,34,0.15);
  `;
  powerRing.appendChild(inner);

  const label = document.createElement("div");
  label.id = "power-label";
  label.style.cssText = `
    position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
    font-size:18px;font-weight:700;color:#fff;
  `;
  label.textContent = "0";
  powerRing.appendChild(label);

  uiRoot.appendChild(powerRing);
}

function createResultPanel() {
  resultPanel = document.createElement("div");
  resultPanel.id = "result-panel";
  resultPanel.style.cssText = `
    position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
    background:rgba(10,10,30,0.94);border-radius:16px;padding:36px 48px;
    color:#fff;text-align:center;min-width:380px;
    display:none;pointer-events:auto;
    box-shadow:0 8px 40px rgba(0,0,0,0.5);
    border:1px solid rgba(255,255,255,0.1);
  `;
  uiRoot.appendChild(resultPanel);
}

function createCountdownOverlay() {
  countdownOverlay = document.createElement("div");
  countdownOverlay.id = "countdown-overlay";
  countdownOverlay.style.cssText = `
    position:absolute;top:0;left:0;width:100%;height:100%;
    display:none;justify-content:center;align-items:center;
    background:rgba(0,0,0,0.5);pointer-events:none;
  `;

  const text = document.createElement("div");
  text.id = "countdown-text";
  text.style.cssText = `
    font-size:120px;font-weight:900;color:#fff;
    text-shadow:0 0 40px rgba(255,152,0,0.5);
    animation:pulse 0.8s ease-out;
  `;
  text.textContent = "3";
  countdownOverlay.appendChild(text);

  uiRoot.appendChild(countdownOverlay);
}

// Public UI methods

export function showMenu() {
  menuPanel.style.display = "block";
  hudPanel.style.display = "none";
  resultPanel.style.display = "none";
  countdownOverlay.style.display = "none";
}

export function hideMenu() {
  menuPanel.style.display = "none";
}

export function showHUD() {
  hudPanel.style.display = "flex";
  // Hide timer label + timer in practice mode
  if (selectedMode === "practice") {
    timerEl.parentElement.style.visibility = "hidden";
  } else {
    timerEl.parentElement.style.visibility = "visible";
  }
}

export function hideHUD() {
  hudPanel.style.display = "none";
}

export function updateTimer(seconds) {
  if (timerEl) {
    timerEl.textContent = Math.max(0, Math.ceil(seconds));
    if (seconds <= 10) {
      timerEl.style.color = "#ff4444";
    } else {
      timerEl.style.color = "#fff";
    }
  }
}

export function updateScore(score, combo, totalShots, totalMakes) {
  if (scoreEl) scoreEl.textContent = score;
  if (shotCountEl) shotCountEl.textContent = `${totalMakes}/${totalShots}`;

  const pct = totalShots > 0 ? Math.round((totalMakes / totalShots) * 100) : 0;
  if (accuracyEl) accuracyEl.textContent = `${pct}%`;

  if (comboEl) {
    if (combo >= 2) {
      comboEl.style.display = "inline";
      comboEl.textContent = `🔥x${combo}`;
    } else {
      comboEl.style.display = "none";
    }
  }
}

export function showResult(data) {
  resultPanel.style.display = "block";

  const team = getTeamById(selectedTeamId);
  resultPanel.innerHTML = `
    <h2 style="margin:0 0 8px;font-size:26px;">比赛结束</h2>
    <p style="margin:0 0 24px;color:#aaa;font-size:14px;">
      <span style="color:${team.primary};">${team.name}</span> — ${team.player}
    </p>
    <div style="font-size:56px;font-weight:900;color:#ff9800;margin-bottom:8px;">${data.score}</div>
    <div style="font-size:14px;color:#888;margin-bottom:24px;">总得分</div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:28px;">
      <div>
        <div style="font-size:24px;font-weight:700;">${data.totalShots}</div>
        <div style="font-size:12px;color:#888;">出手</div>
      </div>
      <div>
        <div style="font-size:24px;font-weight:700;">${data.totalMakes}</div>
        <div style="font-size:12px;color:#888;">命中</div>
      </div>
      <div>
        <div style="font-size:24px;font-weight:700;">${data.pct}%</div>
        <div style="font-size:12px;color:#888;">命中率</div>
      </div>
    </div>
    <div style="margin-bottom:24px;font-size:13px;color:#888;">
      最长连中：<span style="color:#ff5722;font-weight:700;">${data.maxCombo} 连中</span>
    </div>
    <button id="btn-replay" style="
      padding:14px 48px;border-radius:12px;border:none;
      background:linear-gradient(135deg,#ff5722,#e91e63);color:#fff;
      font-size:16px;font-weight:700;cursor:pointer;
      box-shadow:0 4px 20px rgba(255,87,34,0.4);
      margin-right:12px;
    ">再来一局</button>
    <button id="btn-menu" style="
      padding:14px 48px;border-radius:12px;border:2px solid rgba(255,255,255,0.2);
      background:transparent;color:#fff;
      font-size:16px;font-weight:600;cursor:pointer;
    ">返回菜单</button>
  `;

  document.getElementById("btn-replay").addEventListener("click", () => {
    resultPanel.style.display = "none";
    if (onStartGame) onStartGame(selectedMode, selectedTeamId);
  });
  document.getElementById("btn-menu").addEventListener("click", () => {
    resultPanel.style.display = "none";
    if (onReturnMenu) onReturnMenu();
  });
}

export function showCountdown(number, callback) {
  countdownOverlay.style.display = "flex";
  const text = document.getElementById("countdown-text");
  text.textContent = number > 0 ? number : "GO!";
  text.style.animation = "none";
  text.offsetHeight;
  text.style.animation = "pulse 0.8s ease-out";

  if (number > 1) {
    setTimeout(() => showCountdown(number - 1, callback), 800);
  } else {
    setTimeout(() => {
      countdownOverlay.style.display = "none";
      if (callback) callback();
    }, 600);
  }
}

export function showPowerRing(x, y, power, maxPower) {
  powerRing.style.display = "block";
  powerRing.style.left = x + "px";
  powerRing.style.top = y + "px";

  const pct = Math.min(power / maxPower, 1);
  const inner = document.getElementById("power-inner");
  const label = document.getElementById("power-label");

  // Color transitions
  let color;
  if (pct < 0.5) color = `rgba(76,175,80,${0.2 + pct})`;
  else if (pct < 0.85) color = `rgba(255,152,0,${0.2 + pct})`;
  else color = `rgba(255,68,68,${0.3 + pct * 0.5})`;

  inner.style.background = `radial-gradient(circle, ${color} 0%, rgba(0,0,0,0) 70%)`;

  const borderColor = pct < 0.85
    ? `rgba(255,255,255,${0.3 + pct * 0.5})`
    : `rgba(255,68,68,${0.5 + pct})`;
  powerRing.style.borderColor = borderColor;

  label.textContent = Math.round(power);
  label.style.color = pct > 0.9 ? "#ff4444" : "#fff";
}

export function hidePowerRing() {
  powerRing.style.display = "none";
}

export function showFloatingText(x, y, text, color = "#ff9800", size = 24) {
  const el = document.createElement("div");
  el.textContent = text;
  el.style.cssText = `
    position:absolute;left:${x}px;top:${y}px;
    font-size:${size}px;font-weight:900;color:${color};
    pointer-events:none;white-space:nowrap;
    text-shadow:0 2px 8px rgba(0,0,0,0.5);
    animation:floatUp 1s ease-out forwards;
  `;
  floatContainer.appendChild(el);
  setTimeout(() => el.remove(), 1000);
}

export function showScreenShake() {
  uiRoot.style.animation = "shake 0.3s ease-out";
  setTimeout(() => { uiRoot.style.animation = ""; }, 300);
}

export function setHUDPracticeMode() {
  if (timerEl) timerEl.parentElement.style.visibility = "hidden";
  document.getElementById("hud-timer").textContent = "∞";
  document.getElementById("hud-timer").style.visibility = "visible";
  document.getElementById("hud-timer").style.color = "#888";
  document.getElementById("hud-timer").style.fontSize = "28px";
}

export function setHUDChallengeMode() {
  if (timerEl) {
    timerEl.parentElement.style.visibility = "visible";
    timerEl.style.fontSize = "36px";
  }
}
