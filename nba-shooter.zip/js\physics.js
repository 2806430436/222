﻿import * as THREE from "three";
import { getBall, getRim, getBackboard, getHoopPosition, getRimRadius, getBallRadius } from "./scene.js";

const GRAVITY = 32;          // ft/s² feel
const BOUNCE_DAMPING = 0.55; // velocity retained on bounce
const RIM_BOUNCE_DAMPING = 0.45;

let ballVelocity = new THREE.Vector3();
let ballActive = false;
let ballTrail = [];

// Callbacks
let onScoreCallback = null;
let onMissCallback = null;

export function setOnScore(cb) { onScoreCallback = cb; }
export function setOnMiss(cb) { onMissCallback = cb; }
export function isBallActive() { return ballActive; }

export function launchBall(velocity) {
  const ball = getBall();
  if (!ball) return;
  ballVelocity.copy(velocity);
  ballActive = true;
  ball.visible = true;
  ballTrail = [];
}

export function resetBall(shootingPos) {
  const ball = getBall();
  if (!ball) return;
  ballActive = false;
  ball.visible = true;
  ballVelocity.set(0, 0, 0);
  ball.position.copy(shootingPos);
  ballTrail = [];
}

export function getBallVelocity() {
  return ballVelocity;
}

function checkRimCollision(ballPos, prevPos) {
  const rim = getRim();
  if (!rim) return null;

  const rimWorldPos = rim.position.clone();
  const rimRadius = getRimRadius();
  const ballRadius = getBallRadius();

  // Check if ball crossed the rim height plane
  const rimY = rimWorldPos.y;
  const crossedRimPlane = (prevPos.y > rimY && ballPos.y <= rimY) ||
                          (prevPos.y < rimY && ballPos.y >= rimY);

  // Horizontal distance from rim center
  const dx = ballPos.x - rimWorldPos.x;
  const dz = ballPos.z - rimWorldPos.z;
  const horizontalDist = Math.sqrt(dx * dx + dz * dz);

  // Check if ball is near the rim horizontally
  if (crossedRimPlane && ballPos.y <= rimY + ballRadius && ballPos.y >= rimY - ballRadius * 2) {
    // Ball inside rim (score!)
    if (horizontalDist < rimRadius - ballRadius * 0.8) {
      return { type: "score" };
    }
    // Ball hitting rim edge
    if (horizontalDist < rimRadius + ballRadius && horizontalDist > rimRadius - ballRadius) {
      return { type: "rim_bounce", rimCenter: rimWorldPos.clone() };
    }
  }

  // Also check for side collision (ball at rim height near rim)
  if (Math.abs(ballPos.y - rimY) < ballRadius * 1.5 &&
      horizontalDist < rimRadius + ballRadius &&
      horizontalDist > rimRadius - ballRadius) {
    return { type: "rim_bounce", rimCenter: rimWorldPos.clone() };
  }

  return null;
}

function checkBackboardCollision(ballPos) {
  const bb = getBackboard();
  if (!bb) return null;

  const bbBox = new THREE.Box3().setFromObject(bb);
  const ballRadius = getBallRadius();

  // Slightly expand the box for the ball radius
  const expandedBox = bbBox.clone().expandByScalar(ballRadius);

  if (expandedBox.containsPoint(ballPos)) {
    return { type: "backboard", box: bbBox };
  }
  return null;
}

function checkFloorCollision(ballPos) {
  const ballRadius = getBallRadius();
  if (ballPos.y <= ballRadius) {
    return { type: "floor" };
  }
  return null;
}

function handleRimBounce(ballPos, rimCenter) {
  // Push ball out of rim collision
  const dx = ballPos.x - rimCenter.x;
  const dz = ballPos.z - rimCenter.z;
  const dist = Math.sqrt(dx * dx + dz * dz);
  const rimRadius = getRimRadius();
  const ballRadius = getBallRadius();

  if (dist > 0.01) {
    const pushDist = rimRadius + ballRadius - dist + 0.02;
    ballPos.x += (dx / dist) * pushDist;
    ballPos.z += (dz / dist) * pushDist;
  }

  // Reflect horizontal velocity
  if (dist > 0.01) {
    const nx = dx / dist;
    const nz = dz / dist;
    const dot = ballVelocity.x * nx + ballVelocity.z * nz;
    if (dot < 0) {
      ballVelocity.x -= 2 * dot * nx;
      ballVelocity.z -= 2 * dot * nz;
      // Reduce velocity
      ballVelocity.x *= RIM_BOUNCE_DAMPING;
      ballVelocity.z *= RIM_BOUNCE_DAMPING;
      ballVelocity.y *= 0.7;
    }
  }
}

function handleBackboardBounce(ballPos) {
  const bb = getBackboard();
  if (!bb) return;

  const bbBox = new THREE.Box3().setFromObject(bb);
  const ballRadius = getBallRadius();

  // Determine which face of the backboard was hit
  const cx = (bbBox.min.x + bbBox.max.x) / 2;
  const cz = (bbBox.min.z + bbBox.max.z) / 2;

  // Face closest to ball
  if (Math.abs(ballPos.z - bbBox.min.z) < Math.abs(ballPos.z - bbBox.max.z)) {
    ballPos.z = bbBox.min.z - ballRadius;
    if (ballVelocity.z < 0) ballVelocity.z *= -BOUNCE_DAMPING;
  } else {
    ballPos.z = bbBox.max.z + ballRadius;
    if (ballVelocity.z > 0) ballVelocity.z *= -BOUNCE_DAMPING;
  }

  if (ballPos.x < bbBox.min.x) ballPos.x = bbBox.min.x + ballRadius;
  if (ballPos.x > bbBox.max.x) ballPos.x = bbBox.max.x - ballRadius;
  if (ballPos.y < bbBox.min.y) ballPos.y = bbBox.min.y + ballRadius;
  if (ballPos.y > bbBox.max.y) ballPos.y = bbBox.max.y - ballRadius;

  ballVelocity.x *= BOUNCE_DAMPING * 0.8;
  ballVelocity.y *= BOUNCE_DAMPING * 0.8;
}

function handleFloorBounce(ballPos) {
  const ballRadius = getBallRadius();
  ballPos.y = ballRadius;
  if (ballVelocity.y < 0) {
    ballVelocity.y *= -BOUNCE_DAMPING * 0.7;
    ballVelocity.x *= 0.8;
    ballVelocity.z *= 0.8;
  }
  // If velocity is very small, stop bouncing
  if (Math.abs(ballVelocity.y) < 0.5) {
    ballVelocity.y = 0;
    ballPos.y = ballRadius;
  }
}

export function updatePhysics(dt) {
  if (!ballActive) return;

  const ball = getBall();
  if (!ball) return;

  const prevPos = ball.position.clone();

  // Apply gravity
  ballVelocity.y -= GRAVITY * dt;

  // Update position
  ball.position.x += ballVelocity.x * dt;
  ball.position.y += ballVelocity.y * dt;
  ball.position.z += ballVelocity.z * dt;

  // Rotate ball based on velocity
  const speed = ballVelocity.length();
  if (speed > 0.1) {
    const axis = new THREE.Vector3().crossVectors(
      new THREE.Vector3(0, 1, 0),
      ballVelocity.clone().normalize()
    ).normalize();
    ball.rotateOnWorldAxis(axis, speed * dt * 3);
  }

  // Collision checks
  const rimResult = checkRimCollision(ball.position, prevPos);
  if (rimResult) {
    if (rimResult.type === "score") {
      if (ballVelocity.y < -2) {
        // Ball passing downward through rim
        ballActive = false;
        if (onScoreCallback) onScoreCallback();
      }
    } else if (rimResult.type === "rim_bounce") {
      handleRimBounce(ball.position, rimResult.rimCenter);
    }
  }

  const bbResult = checkBackboardCollision(ball.position);
  if (bbResult) {
    handleBackboardBounce(ball.position);
  }

  const floorResult = checkFloorCollision(ball.position);
  if (floorResult) {
    handleFloorBounce(ball.position);
    // Ball settled on floor - deactivate
    if (Math.abs(ballVelocity.y) < 0.5 && Math.abs(ballVelocity.x) < 0.3 && Math.abs(ballVelocity.z) < 0.3) {
      ballActive = false;
      if (onMissCallback) onMissCallback();
    }
  }

  // Out of bounds
  if (ball.position.y < -5 || Math.abs(ball.position.x) > 25 || ball.position.z > 10 || ball.position.z < -30) {
    ballActive = false;
    ball.visible = false;
    if (onMissCallback) onMissCallback();
  }
}
