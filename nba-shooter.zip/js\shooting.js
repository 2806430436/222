﻿import * as THREE from "three";
import { launchBall, isBallActive, resetBall } from "./physics.js";
import { getHoopPosition, getBall, getCamera, getRenderer } from "./scene.js";

const MAX_POWER = 100;
const POWER_RATE = 90;       // power units per second
const BASE_SPEED = 0.55;    // base speed multiplier per power unit
const AIM_SENSITIVITY = 0.025;

let isCharging = false;
let power = 0;
let mouseDownPos = { x: 0, y: 0 };
let mouseCurrentPos = { x: 0, y: 0 };
let shootingPosition = new THREE.Vector3(0, 5.5, 0);
let onPowerChange = null;
let onShotTaken = null;
let canShoot = true;

export function setOnPowerChange(cb) { onPowerChange = cb; }
export function setOnShotTaken(cb) { onShotTaken = cb; }
export function getIsCharging() { return isCharging; }
export function getPower() { return power; }
export function getMouseDownPos() { return mouseDownPos; }
export function getMouseCurrentPos() { return mouseCurrentPos; }

export function setShootingPosition(pos) {
  shootingPosition.copy(pos);
  resetBall(shootingPosition);
}

export function getShootingPosition() {
  return shootingPosition.clone();
}

export function setCanShoot(val) {
  canShoot = val;
}

function getCanvasPos(e) {
  const renderer = getRenderer();
  if (!renderer) return { x: 0, y: 0 };
  const rect = renderer.domElement.getBoundingClientRect();
  return {
    x: e.clientX - rect.left,
    y: e.clientY - rect.top
  };
}

function onMouseDown(e) {
  if (!canShoot) return;
  if (e.button !== 0) return;
  if (isBallActive()) return;

  isCharging = true;
  power = 0;
  const pos = getCanvasPos(e);
  mouseDownPos = pos;
  mouseCurrentPos = pos;
}

function onMouseMove(e) {
  if (!isCharging) return;
  mouseCurrentPos = getCanvasPos(e);
}

function onMouseUp(e) {
  if (!isCharging) return;
  isCharging = false;

  const pos = getCanvasPos(e);
  mouseCurrentPos = pos;

  // Calculate aim offset
  const dx = mouseCurrentPos.x - mouseDownPos.x;
  const dy = mouseCurrentPos.y - mouseDownPos.y;

  // Direction toward hoop
  const hoopPos = getHoopPosition();
  const toHoop = new THREE.Vector3().subVectors(hoopPos, shootingPosition).normalize();

  // Base launch direction (toward hoop with slight arc)
  const launchDir = toHoop.clone();
  launchDir.y += 0.45; // aim upward toward the hoop

  // Add horizontal aim adjustment
  const rightAxis = new THREE.Vector3().crossVectors(
    new THREE.Vector3(0, 1, 0),
    toHoop
  ).normalize();

  launchDir.add(rightAxis.clone().multiplyScalar(dx * AIM_SENSITIVITY));
  launchDir.y += dy * AIM_SENSITIVITY * 0.5;
  launchDir.normalize();

  // Clamp power
  const finalPower = Math.min(power, MAX_POWER);
  const speed = finalPower * BASE_SPEED;

  // Launch!
  const velocity = launchDir.multiplyScalar(speed);
  launchBall(velocity);

  // Move ball to shooting position
  const ball = getBall();
  if (ball) {
    ball.position.copy(shootingPosition);
  }

  power = 0;
  if (onPowerChange) onPowerChange(0);
  if (onShotTaken) onShotTaken();
}

function onTouchStart(e) {
  if (!canShoot) return;
  if (isBallActive()) return;
  e.preventDefault();

  isCharging = true;
  power = 0;
  const touch = e.touches[0];
  const pos = { x: touch.clientX, y: touch.clientY };
  // Convert to canvas coords
  const renderer = getRenderer();
  if (renderer) {
    const rect = renderer.domElement.getBoundingClientRect();
    pos.x -= rect.left;
    pos.y -= rect.top;
  }
  mouseDownPos = pos;
  mouseCurrentPos = pos;
}

function onTouchMove(e) {
  if (!isCharging) return;
  e.preventDefault();
  const touch = e.touches[0];
  const pos = { x: touch.clientX, y: touch.clientY };
  const renderer = getRenderer();
  if (renderer) {
    const rect = renderer.domElement.getBoundingClientRect();
    pos.x -= rect.left;
    pos.y -= rect.top;
  }
  mouseCurrentPos = pos;
}

function onTouchEnd(e) {
  if (!isCharging) return;
  isCharging = false;
  e.preventDefault();

  const dx = mouseCurrentPos.x - mouseDownPos.x;
  const dy = mouseCurrentPos.y - mouseDownPos.y;

  const hoopPos = getHoopPosition();
  const toHoop = new THREE.Vector3().subVectors(hoopPos, shootingPosition).normalize();

  const launchDir = toHoop.clone();
  launchDir.y += 0.45;

  const rightAxis = new THREE.Vector3().crossVectors(
    new THREE.Vector3(0, 1, 0),
    toHoop
  ).normalize();

  launchDir.add(rightAxis.clone().multiplyScalar(dx * AIM_SENSITIVITY));
  launchDir.y += dy * AIM_SENSITIVITY * 0.5;
  launchDir.normalize();

  const finalPower = Math.min(power, MAX_POWER);
  const speed = finalPower * BASE_SPEED;

  const velocity = launchDir.multiplyScalar(speed);
  launchBall(velocity);

  const ball = getBall();
  if (ball) {
    ball.position.copy(shootingPosition);
  }

  power = 0;
  if (onPowerChange) onPowerChange(0);
  if (onShotTaken) onShotTaken();
}

export function initShooting(canvasEl) {
  canvasEl.addEventListener("mousedown", onMouseDown);
  canvasEl.addEventListener("mousemove", onMouseMove);
  canvasEl.addEventListener("mouseup", onMouseUp);
  canvasEl.addEventListener("mouseleave", onMouseUp);
  canvasEl.addEventListener("touchstart", onTouchStart, { passive: false });
  canvasEl.addEventListener("touchmove", onTouchMove, { passive: false });
  canvasEl.addEventListener("touchend", onTouchEnd);
}

export function updateCharging(dt) {
  if (isCharging && power < MAX_POWER) {
    power += POWER_RATE * dt;
    if (power > MAX_POWER) power = MAX_POWER;
    if (onPowerChange) onPowerChange(power);
  }
}
