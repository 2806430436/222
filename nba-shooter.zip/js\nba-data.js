﻿// NBA 30 teams data with colors and star players
export const NBA_TEAMS = [
  { id: "ATL", name: "Atlanta Hawks", player: "Trae Young", primary: "#E03A3E", secondary: "#C1D32F" },
  { id: "BOS", name: "Boston Celtics", player: "Jayson Tatum", primary: "#007A33", secondary: "#BA9653" },
  { id: "BKN", name: "Brooklyn Nets", player: "Mikal Bridges", primary: "#000000", secondary: "#FFFFFF" },
  { id: "CHA", name: "Charlotte Hornets", player: "LaMelo Ball", primary: "#1D1160", secondary: "#00788C" },
  { id: "CHI", name: "Chicago Bulls", player: "Zach LaVine", primary: "#CE1141", secondary: "#000000" },
  { id: "CLE", name: "Cleveland Cavaliers", player: "Donovan Mitchell", primary: "#860038", secondary: "#FDBB30" },
  { id: "DAL", name: "Dallas Mavericks", player: "Luka Dončić", primary: "#00538C", secondary: "#002B5E" },
  { id: "DEN", name: "Denver Nuggets", player: "Nikola Jokić", primary: "#0E2240", secondary: "#FEC524" },
  { id: "DET", name: "Detroit Pistons", player: "Cade Cunningham", primary: "#C8102E", secondary: "#006BB6" },
  { id: "GSW", name: "Golden State Warriors", player: "Stephen Curry", primary: "#1D428A", secondary: "#FFC72C" },
  { id: "HOU", name: "Houston Rockets", player: "Jalen Green", primary: "#CE1141", secondary: "#000000" },
  { id: "IND", name: "Indiana Pacers", player: "Tyrese Haliburton", primary: "#002D62", secondary: "#FDBB30" },
  { id: "LAC", name: "LA Clippers", player: "Kawhi Leonard", primary: "#C8102E", secondary: "#1D428A" },
  { id: "LAL", name: "Los Angeles Lakers", player: "LeBron James", primary: "#552583", secondary: "#FDB927" },
  { id: "MEM", name: "Memphis Grizzlies", player: "Ja Morant", primary: "#5D76A9", secondary: "#12173F" },
  { id: "MIA", name: "Miami Heat", player: "Jimmy Butler", primary: "#98002E", secondary: "#F9A01B" },
  { id: "MIL", name: "Milwaukee Bucks", player: "Giannis Antetokounmpo", primary: "#00471B", secondary: "#EEE1C6" },
  { id: "MIN", name: "Minnesota Timberwolves", player: "Anthony Edwards", primary: "#0C2340", secondary: "#78BE20" },
  { id: "NOP", name: "New Orleans Pelicans", player: "Zion Williamson", primary: "#0C2340", secondary: "#C8102E" },
  { id: "NYK", name: "New York Knicks", player: "Jalen Brunson", primary: "#006BB6", secondary: "#F58426" },
  { id: "OKC", name: "Oklahoma City Thunder", player: "Shai Gilgeous-Alexander", primary: "#007AC1", secondary: "#EF3B24" },
  { id: "ORL", name: "Orlando Magic", player: "Paolo Banchero", primary: "#0077C0", secondary: "#000000" },
  { id: "PHI", name: "Philadelphia 76ers", player: "Joel Embiid", primary: "#006BB6", secondary: "#ED174C" },
  { id: "PHX", name: "Phoenix Suns", player: "Devin Booker", primary: "#E56020", secondary: "#1D1160" },
  { id: "POR", name: "Portland Trail Blazers", player: "Damian Lillard", primary: "#E03A3E", secondary: "#000000" },
  { id: "SAC", name: "Sacramento Kings", player: "De''Aaron Fox", primary: "#5A2D81", secondary: "#63727A" },
  { id: "SAS", name: "San Antonio Spurs", player: "Victor Wembanyama", primary: "#000000", secondary: "#C4CED4" },
  { id: "TOR", name: "Toronto Raptors", player: "Scottie Barnes", primary: "#CE1141", secondary: "#000000" },
  { id: "UTA", name: "Utah Jazz", player: "Lauri Markkanen", primary: "#002B5C", secondary: "#F9A01B" },
  { id: "WAS", name: "Washington Wizards", player: "Kyle Kuzma", primary: "#E31837", secondary: "#002B5C" }
];

export function getTeamById(id) {
  return NBA_TEAMS.find(t => t.id === id);
}
