import os
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)

# Load .env from project root
load_dotenv(os.path.join(ROOT_DIR, ".env"))

OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

FAQ_PATH = os.path.join(ROOT_DIR, "data", "faq.json")
DATABASE_PATH = os.path.join(ROOT_DIR, "data", "chat.db")

MAX_HISTORY_ROUNDS = 10
FAQ_TOP_K = 3
FAQ_SIMILARITY_THRESHOLD = 0.3
