import traceback
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from models import ChatRequest, ChatResponse
from db import init_db, get_history, save_message, clear_session as db_clear_session
from llm import chat as llm_chat

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="速购电商客服机器人", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_db()


@app.post("/api/chat", response_model=ChatResponse)
def chat_endpoint(req: ChatRequest):
    try:
        history = get_history(req.session_id)
        save_message(req.session_id, "user", req.message)
        reply = llm_chat(req.message, history)
        save_message(req.session_id, "assistant", reply)
        return ChatResponse(reply=reply, session_id=req.session_id)
    except Exception as e:
        logger.error(f"Chat error: {traceback.format_exc()}")
        msg = str(e)
        if len(msg) > 200:
            msg = msg[:200] + "..."
        raise HTTPException(status_code=500, detail=f"服务暂时不可用，请稍后重试")


@app.get("/api/conversations/{session_id}")
def get_conversation(session_id: str):
    history = get_history(session_id)
    return {"session_id": session_id, "messages": history}


@app.delete("/api/conversations/{session_id}")
def clear_conversation(session_id: str):
    db_clear_session(session_id)
    return {"status": "ok", "message": "会话已清除"}


static_dir = os.path.join(os.path.dirname(__file__), "..", "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def index():
    return FileResponse(os.path.join(static_dir, "index.html"))