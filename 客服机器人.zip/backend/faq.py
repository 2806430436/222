import json
import os
from difflib import SequenceMatcher
from config import FAQ_PATH, FAQ_TOP_K, FAQ_SIMILARITY_THRESHOLD

_faq_data: list[dict] = []
_faq_mtime: float = 0


def _load_faq():
    global _faq_data, _faq_mtime
    try:
        mtime = os.path.getmtime(FAQ_PATH)
        if mtime != _faq_mtime:
            with open(FAQ_PATH, "r", encoding="utf-8") as f:
                _faq_data = json.load(f)
            _faq_mtime = mtime
    except FileNotFoundError:
        _faq_data = []


def _similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def search_faq(query: str) -> list[dict]:
    _load_faq()
    if not _faq_data:
        return []

    scored = []
    for item in _faq_data:
        q_text = item.get("question", "")
        kw_text = " ".join(item.get("keywords", []))
        combined = f"{q_text} {kw_text}"
        score = _similarity(query, combined)
        if score >= FAQ_SIMILARITY_THRESHOLD:
            scored.append((score, item))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in scored[:FAQ_TOP_K]]


def format_faq_context(faq_items: list[dict]) -> str:
    if not faq_items:
        return ""
    lines = ["以下是可能与当前问题相关的FAQ信息，请参考但不要逐字复述："]
    for i, item in enumerate(faq_items, 1):
        lines.append(f"{i}. 问：{item['question']}\n   答：{item['answer']}")
    return "\n".join(lines)
