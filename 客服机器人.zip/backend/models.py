from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    session_id: str = Field(..., description="会话ID")
    message: str = Field(..., min_length=1, max_length=2000, description="用户消息")


class ChatResponse(BaseModel):
    reply: str = Field(..., description="AI回复")
    session_id: str = Field(..., description="会话ID")


class MessageItem(BaseModel):
    role: str
    content: str
    created_at: str
