from openai import OpenAI
from config import OPENAI_BASE_URL, OPENAI_API_KEY, OPENAI_MODEL, MAX_HISTORY_ROUNDS
from faq import search_faq, format_faq_context

SYSTEM_PROMPT = """你是"速购电商"的客服助手，名叫小速。你的职责是帮助客户解决订单查询、物流跟踪、退换货、产品咨询、优惠活动等问题。

回复规则：
- 语气亲切、专业、简洁，像真人客服一样自然对话
- 如果用户的提问在提供的FAQ参考资料中有明确答案，以FAQ为准回答，但用自己的话组织语言，不要逐字复述
- 不要编造你无法确认的信息（比如具体的订单号、物流单号、退款金额等），遇到此类问题引导客户提供订单号或联系人工客服
- 回复尽量控制在150字以内，简洁明了
- 如果用户打招呼或闲聊，友好回应并引导说明具体需求"""

_client: OpenAI | None = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(
            base_url=OPENAI_BASE_URL,
            api_key=OPENAI_API_KEY,
        )
    return _client


def chat(user_message: str, history: list[dict]) -> str:
    if not OPENAI_API_KEY:
        return "抱歉，客服系统尚未配置完成，请稍后再试。如急需帮助，请联系人工客服。"

    faq_items = search_faq(user_message)
    faq_text = format_faq_context(faq_items)

    system_content = SYSTEM_PROMPT
    if faq_text:
        system_content += "\n\n" + faq_text

    messages = [{"role": "system", "content": system_content}]

    recent_history = history[-(MAX_HISTORY_ROUNDS * 2):]
    for msg in recent_history:
        messages.append({"role": msg["role"], "content": msg["content"]})

    messages.append({"role": "user", "content": user_message})

    response = _get_client().chat.completions.create(
        model=OPENAI_MODEL,
        messages=messages,
        temperature=0.7,
        max_tokens=500,
    )

    return response.choices[0].message.content
