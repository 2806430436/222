(function () {
  "use strict";

  var script = document.currentScript;
  var API_BASE = script.getAttribute("data-api") || "/api/chat";
  if (API_BASE.startsWith("/")) {
    API_BASE = window.location.origin + API_BASE;
  }
  var CONVERSATIONS_API = API_BASE.replace(/\/chat$/, "/conversations");

  function getSessionId() {
    var id = localStorage.getItem("cs_session_id");
    if (!id) {
      id = "sess_" + Date.now() + "_" + Math.random().toString(36).slice(2, 11);
      localStorage.setItem("cs_session_id", id);
    }
    return id;
  }

  function el(tag, cls, attrs, children) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === "html") e.innerHTML = attrs[k];
        else if (k === "text") e.textContent = attrs[k];
        else e.setAttribute(k, attrs[k]);
      });
    }
    if (children) {
      children.forEach(function (c) {
        if (typeof c === "string") e.appendChild(document.createTextNode(c));
        else e.appendChild(c);
      });
    }
    return e;
  }

  var ICONS = {
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',
    headset: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>',
  };

  var sessionId = getSessionId();
  var isLoading = false;

  var wrapper = el("div", "cs-widget");

  var bubbleBtn = el("button", "cs-bubble");
  bubbleBtn.innerHTML = ICONS.chat;
  bubbleBtn.title = "联系客服";
  wrapper.appendChild(bubbleBtn);

  var panel = el("div", "cs-panel closed");

  var header = el("div", "cs-header");
  var headerInfo = el("div", "cs-header-info");
  var avatar = el("div", "cs-avatar");
  avatar.innerHTML = ICONS.headset;
  headerInfo.appendChild(avatar);
  var headerText = el("div", "cs-header-text");
  headerText.appendChild(el("span", "cs-header-name", { text: "速购客服" }));
  headerText.appendChild(el("span", "cs-header-status", { text: "在线 \u00b7 智能助手" }));
  headerInfo.appendChild(headerText);
  header.appendChild(headerInfo);

  var closeBtn = el("button", "cs-close", { title: "关闭" });
  closeBtn.innerHTML = ICONS.close;
  header.appendChild(closeBtn);
  panel.appendChild(header);

  var messagesEl = el("div", "cs-messages");
  panel.appendChild(messagesEl);

  var inputArea = el("div", "cs-input-area");
  var inputEl = el("textarea", "cs-input", {
    placeholder: "输入您的问题...",
    rows: "1",
  });
  var sendBtn = el("button", "cs-send", { title: "发送" });
  sendBtn.innerHTML = ICONS.send;
  inputArea.appendChild(inputEl);
  inputArea.appendChild(sendBtn);
  panel.appendChild(inputArea);

  wrapper.appendChild(panel);
  document.body.appendChild(wrapper);

  var cssId = "cs-widget-style";
  if (!document.getElementById(cssId)) {
    var link = document.createElement("link");
    link.id = cssId;
    link.rel = "stylesheet";
    var scriptSrc = script.src;
    var cssHref = scriptSrc.replace(/\.js(\?.*)?$/, ".css");
    link.href = cssHref;
    document.head.appendChild(link);
  }

  function scrollBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addMessage(role, content, time) {
    var msgDiv = el("div", "cs-msg " + role);
    var bubble = el("div", "cs-msg-bubble", { text: content });
    msgDiv.appendChild(bubble);
    if (time) {
      var timeEl = el("div", "cs-msg-time", { text: time });
      msgDiv.appendChild(timeEl);
    }
    messagesEl.appendChild(msgDiv);
    scrollBottom();
  }

  function formatTime() {
    var d = new Date();
    var h = d.getHours().toString().padStart(2, "0");
    var m = d.getMinutes().toString().padStart(2, "0");
    return h + ":" + m;
  }

  function showTyping() {
    var typing = el("div", "cs-typing");
    for (var i = 0; i < 3; i++) {
      typing.appendChild(el("div", "cs-typing-dot"));
    }
    typing.id = "cs-typing-indicator";
    messagesEl.appendChild(typing);
    scrollBottom();
  }

  function hideTyping() {
    var t = document.getElementById("cs-typing-indicator");
    if (t) t.remove();
  }

  function showError(text) {
    hideTyping();
    // Truncate long error messages (like Python tracebacks)
    var short = text;
    if (text.length > 150) {
      short = text.slice(0, 150) + "...";
    }
    // Remove Python traceback patterns
    short = short.replace(/File\s+"[^"]+".*$/g, "").trim();
    if (!short) short = "服务暂时不可用，请稍后重试";
    var errEl = el("div", "cs-error", { text: short });
    messagesEl.appendChild(errEl);
    scrollBottom();
  }

  function sendMessage() {
    var msg = inputEl.value.trim();
    if (!msg || isLoading) return;

    isLoading = true;
    sendBtn.disabled = true;
    inputEl.value = "";
    inputEl.style.height = "auto";

    var time = formatTime();
    addMessage("user", msg, time);
    showTyping();

    fetch(API_BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, message: msg }),
    })
      .then(function (res) {
        if (!res.ok) {
          return res.json().then(function (err) {
            var detail = err.detail || "请求失败";
            // Truncate error detail
            if (detail.length > 100) detail = detail.slice(0, 100) + "...";
            throw new Error(detail);
          });
        }
        return res.json();
      })
      .then(function (data) {
        hideTyping();
        addMessage("assistant", data.reply, formatTime());
        isLoading = false;
        sendBtn.disabled = false;
        inputEl.focus();
      })
      .catch(function (err) {
        hideTyping();
        var msg = err.message || "网络异常，请稍后重试";
        if (msg.length > 100) msg = msg.slice(0, 100) + "...";
        showError(msg);
        isLoading = false;
        sendBtn.disabled = false;
      });
  }

  function loadHistory() {
    fetch(CONVERSATIONS_API + "/" + sessionId)
      .then(function (res) {
        if (!res.ok) return;
        return res.json();
      })
      .then(function (data) {
        if (data && data.messages && data.messages.length > 0) {
          data.messages.forEach(function (m) {
            var t = m.created_at ? m.created_at.slice(11, 16) : "";
            addMessage(m.role, m.content, t);
          });
        }
      })
      .catch(function () {});
  }

  function clearHistory() {
    fetch(CONVERSATIONS_API + "/" + sessionId, { method: "DELETE" }).catch(
      function () {}
    );
    messagesEl.innerHTML = "";
  }

  bubbleBtn.addEventListener("click", function () {
    panel.classList.remove("closed");
    bubbleBtn.classList.add("hidden");
    inputEl.focus();
  });

  closeBtn.addEventListener("click", function () {
    panel.classList.add("closed");
    bubbleBtn.classList.remove("hidden");
  });

  sendBtn.addEventListener("click", sendMessage);

  inputEl.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  inputEl.addEventListener("input", function () {
    inputEl.style.height = "auto";
    inputEl.style.height = Math.min(inputEl.scrollHeight, 80) + "px";
  });

  loadHistory();
})();