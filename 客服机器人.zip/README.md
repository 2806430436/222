# 电商客服机器人

基于大模型的智能客服聊天组件，可嵌入任意网页，支持自动回复 + FAQ 知识库增强。

## 功能

- **网页内嵌聊天组件**：一行 `<script>` 标签即可嵌入任意网站
- **AI 自动回复**：对接兼容 OpenAI 接口的大模型（DeepSeek / OpenAI / 通义千问等）
- **FAQ 知识库增强**：内置电商售后 FAQ，自动检索并增强回复准确性
- **多轮对话**：支持上下文记忆，连续对话不丢失
- **对话持久化**：SQLite 存储历史记录，刷新页面不丢失

## 快速开始

### 1. 安装依赖

```bash
pip install -r backend/requirements.txt
```

### 2. 配置 API

复制 `.env.example` 为 `.env`，填入你的 API 信息：

```
OPENAI_BASE_URL=https://api.deepseek.com/v1
OPENAI_API_KEY=sk-xxxxxxxx
OPENAI_MODEL=deepseek-chat
```

### 3. 启动服务

```bash
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8080
```

### 4. 打开页面

浏览器访问 `http://localhost:8080`，点击右下角聊天气泡即可开始对话。

## 嵌入你的网站

在你的 HTML 页面中添加一行：

```html
<script src="http://your-domain:8080/static/widget.js" data-api="/api/chat"></script>
```

## 项目结构

```
├── backend/
│   ├── main.py          # FastAPI 入口
│   ├── config.py        # 环境变量配置
│   ├── models.py        # 数据模型
│   ├── db.py            # SQLite 数据库
│   ├── faq.py           # FAQ 检索
│   ├── llm.py           # 大模型调用
│   └── requirements.txt
├── static/
│   ├── index.html       # Demo 页面
│   ├── widget.js        # 聊天组件
│   └── widget.css       # 组件样式
├── data/
│   └── faq.json         # FAQ 知识库（18条电商售后问答）
├── .env.example         # 环境变量模板
└── .gitignore
```

## 自定义 FAQ

编辑 `data/faq.json`，按以下格式添加你的问答：

```json
{
  "id": 1,
  "question": "如何查询订单？",
  "answer": "在「我的订单」页面可查看所有订单状态。",
  "keywords": ["订单", "查询", "状态"]
}
```

修改后无需重启，下次请求自动热加载。